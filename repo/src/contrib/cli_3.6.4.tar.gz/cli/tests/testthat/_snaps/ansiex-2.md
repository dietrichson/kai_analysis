# NA

    Code
      ansi_html(s)
    Output
      [1] "foo"                                         
      [2] NA                                            
      [3] "bar"                                         
      [4] "<span class=\"ansi ansi-bold\">foobar</span>"

