my_filenam = "kai.analysis_0.1.0_R_x86_64-pc-linux-gnu.tar.gz"

rwasm::build("local::/cloud/project/kai.analysis_0.1.0_R_x86_64-pc-linux-gnu.tar.gz",out_dir = "output/")
rwasm::build("local::/cloud/project/kai.analysis_0.1.0.tar.gz",out_dir = "output/")

